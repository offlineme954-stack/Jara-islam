# Zara Islam Birthday Page

Upload `index.html` to a GitHub repository root and enable GitHub Pages: Settings → Pages → Deploy from branch → main → /(root). No server or API key is required.
